exports.handler = async () => {
  console.log("x");
  return { statusCode: 200, body: "deploying" };
};
